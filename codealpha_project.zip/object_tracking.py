# Object Detection & Tracking using YOLOv8 + Deep SORT
# Install dependencies using: pip install -r requirements.txt

import cv2
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort

# ------------------------------
# Step 1: Load YOLOv8 model
# ------------------------------
model = YOLO('yolov8n.pt')  # Pre-trained YOLOv8 Nano model (fast and lightweight)

# ------------------------------
# Step 2: Initialize Deep SORT tracker
# ------------------------------
tracker = DeepSort(
    max_age=30,
    n_init=3,
    nms_max_overlap=1.0,
    max_cosine_distance=0.4,
    nn_budget=None,
    override_track_class=None
)

# ------------------------------
# Step 3: Load Video Input
# ------------------------------
video_path = "sample_video.mp4"  # Replace with your video or set 0 for webcam
cap = cv2.VideoCapture(video_path)

# Video Writer to save output
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = int(cap.get(cv2.CAP_PROP_FPS)) or 30
out = cv2.VideoWriter("output_tracking.mp4", cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))

# ------------------------------
# Step 4: Process Each Frame
# ------------------------------
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # YOLO Object Detection
    results = model.predict(frame, verbose=False)[0]

    detections = []
    for box in results.boxes:
        x1, y1, x2, y2 = box.xyxy[0].tolist()
        conf = float(box.conf[0])
        cls = int(box.cls[0])
        label = model.names[cls]

        if conf > 0.4:  # Confidence threshold
            detections.append([[x1, y1, x2-x1, y2-y1], conf, label])  # [x, y, w, h]

    # Deep SORT Tracking
    tracks = tracker.update_tracks(detections, frame=frame)

    # Draw Tracking Results
    for track in tracks:
        if not track.is_confirmed():
            continue
        track_id = track.track_id
        l, t, r, b = map(int, track.to_ltrb())
        cv2.rectangle(frame, (l, t), (r, b), (0, 255, 0), 2)
        cv2.putText(frame, f"ID {track_id}", (l, t - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # Show & Save Frame
    out.write(frame)
    cv2.imshow("Object Detection & Tracking", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# ------------------------------
# Step 5: Cleanup
# ------------------------------
cap.release()
out.release()
cv2.destroyAllWindows()
