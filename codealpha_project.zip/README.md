# CodeAlpha – Object Detection & Tracking

This project detects and tracks multiple objects in videos using **YOLOv8** for detection and **Deep SORT** for tracking.

## Features
- Real-time object detection and tracking
- Assigns unique IDs to objects
- Saves output video with bounding boxes and IDs

## Installation
1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/codealpha.git
   cd codealpha
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage
1. Add your video file and update `video_path` in `object_tracking.py`.
2. Run the project:
   ```bash
   python object_tracking.py
   ```
3. Output will be saved as **output_tracking.mp4**.

## Tech Stack
- **YOLOv8 (Ultralytics)** – Object detection
- **Deep SORT** – Object tracking
- **OpenCV** – Video processing
- **PyTorch** – Model inference

## Author
Developed as part of the **CodeAlpha AI/ML Internship Project**.
